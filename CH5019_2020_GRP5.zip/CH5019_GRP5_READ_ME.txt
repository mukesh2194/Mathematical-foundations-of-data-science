-- About assumptions in the problems -- 
All the assumptions are written in italics in the explanation of the procedure.


-- About the dataset in problem 3 --
We have used the dataset initially uploaded to Moodle on 14th April.
This data contains information upto 7th April 2020.
All our analysis and discussions are done based on the above mentioned
file-set. Remarks are made considering the situation at that point in time.


-- About the python notebook files --
Please set the directory for the datasets of each problem before running them.
It can be done in the cell immediately below the cell for importing the packages.
All the results are already generated in the notebook files and interpretations
and steps are written in the markdown cells.


-- Exceeding the page limit --
Please note that the report seems to have exceeded the page limit (15)
because we have included the questions in the report.
Excluding them will limit the report to 15 pages.



- Thank you.
- Group-5