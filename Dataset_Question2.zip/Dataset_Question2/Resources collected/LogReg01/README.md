# LogReg01
Logistic Regression using Gradient Descent Optimizer

Using the Iris data set to demonstrate how Logistic regression works from scratch. 
