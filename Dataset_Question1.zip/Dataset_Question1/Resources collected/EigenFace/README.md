# EigenFace

## Overview
A Python class that implements the Eigenfaces algorithm for face recognition, using eigen decomposition and principle component analysis(PCA) for dimensionality reduction.