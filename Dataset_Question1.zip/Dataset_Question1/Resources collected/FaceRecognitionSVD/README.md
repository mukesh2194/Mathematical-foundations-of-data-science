Face Recognition using Singular value decomposition.

This recognition algorithm uses basic object recognition method which is singular value decomposition.
Using SVD function you can train your own images and perform SVD on that images.After that you can test using 
some mathmatical operations with U(eigenface) vector returned by SVD function.

The dataset of the facial images are in "dataimage". The code is show in face_recognition.py file.
The test images are in test_img folder.The accuracy achieved is 85%. 
